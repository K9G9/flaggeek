
# Flaggeek Sitemap

Dette repository indeholder en opdateret sitemap.xml for flagprofiler fra https://www.flaggeek.net.

## Brug

1. Upload `sitemap.xml` til dette GitHub Pages-repository.
2. Tilføj den i Google Search Console som:
   https://<brugernavn>.github.io/flag-sitemaps/sitemap.xml
3. Opdater filen hver gang du tilføjer en ny flagprofil (HTML eller PDF).

---

Denne fil er automatisk genereret af FlagGeek-projektet.
